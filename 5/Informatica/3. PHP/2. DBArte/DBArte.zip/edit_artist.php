<html>

<head>
	<title>Modifica artista</title>
</head>

<body>
	<?php
		if (isset($_GET["AR_CodiceArtista"])) {
			$host = "localhost";
			$user = "root";
			$password = "";
			$db = "arte";

			$connect = new mysqli($host, $user, $password, $db);
			if ($connect->connect_error) {
				exit("Errore connessione: " . $connect->connect_error);
			}

			if (isset($_GET["delete"]) && $_GET["delete"] == "1") {
				$connect->query("DELETE FROM quadri WHERE QQ_CodiceArtista = '".$_GET["AR_CodiceArtista"]."'");

				$connect->query("DELETE FROM artisti WHERE AR_CodiceArtista = '".$_GET["AR_CodiceArtista"]."'");

				header("Location: view_artists.php");
				exit();
			}

			$result = $connect->query("SELECT * FROM artisti WHERE AR_CodiceArtista = '".$_GET["AR_CodiceArtista"]."'");
			$artista = $result->fetch_assoc();
		}
		else {
			exit("Non si può invocare questa pagina senza parametri!");
		}
	?>

	<p>Fai le modifiche e premi Salva</p>

	<form id="formEdit" name="formEdit" method="post" action="update_artist.php">
		<input type="hidden" name="AR_CodiceArtista" id="AR_CodiceArtista" value='<?php echo $artista["AR_CodiceArtista"]; ?>'/>
		Nome <input type="text" name="AR_Nome" id="AR_Nome" value='<?php echo $artista["AR_Nome"]; ?>'/>
		Alias <input type="text" name="AR_Alias" id="AR_Alias" value='<?php echo $artista["AR_Alias"]; ?>'/>
		Data di nascita <input type="text" name="AR_DataNascita" id="AR_DataNascita" value='<?php echo $artista["AR_DataNascita"]; ?>'/>
		Data di morte <input type="text" name="AR_DataMorte" id="AR_DataMorte" value='<?php echo $artista["AR_DataMorte"]; ?>'/>

		<input type="submit" name="salva" id="salva" value="Salva" />
	</form>
</body>

</html>
